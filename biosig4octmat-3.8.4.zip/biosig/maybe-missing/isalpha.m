function b = isalpha(c) 

c=upper(c);
b = (c(1)>='A') & (c(1)<='Z');

